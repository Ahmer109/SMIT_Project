import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smit_project/Admin%20Screens/AdminDashboard.dart';
import 'package:smit_project/Auth/LoginPage.dart';

import '../../User Screens/UserDashboard.dart';

class LoginController {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  TextEditingController Email = TextEditingController();
  TextEditingController Password = TextEditingController();

  Future<void> saveUserFcmToken(String userId) async {
    String? fcmToken = await FirebaseMessaging.instance.getToken();

    if (fcmToken != null) {
      try {
        await FirebaseFirestore.instance.collection('Users').doc(userId).set(
            {
              'fcmToken': fcmToken,
            },
            SetOptions(
                merge: true)); // Use merge to avoid overwriting existing data
        print("FCM token saved successfully");
      } catch (e) {
        print("Error saving FCM token: $e");
      }
    } else {
      print("Failed to get FCM token");
    }
  }

  setprefs(data) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool("Login", true);
    prefs.setString("userType", data["Type"]);
  }

  Future<void> _updateUserStatus(String userId, bool isLoggedIn) async {
    try {
      await _firestore.collection('Users').doc(userId).update({
        'isLoggedIn': isLoggedIn,
      });
      print("User status updated to: $isLoggedIn");
    } catch (e) {
      print("Error updating user status: $e");
    }
  }

  Future<void> checkUser(User user) async {
    try {
      // Check if user exists in "admin" collection
      var adminDoc = await FirebaseFirestore.instance
          .collection("Admin")
          .doc(user.uid)
          .get();
      if (adminDoc.exists) {
        var adminData = adminDoc.data() as Map<String, dynamic>;

        // Check if admin user is blocked
        if (adminData['isBlocked'] == true) {
          Get.snackbar("Error", "Your account is blocked.",
              colorText: Colors.white);
          await FirebaseAuth.instance.signOut(); // Log out the user
          return Get.offAll(LoginPage()); // Exit function after navigating
        }

        await setprefs(adminData); // Save preferences
        // await saveUserFcmToken(user.uid); // Save FCM token for admin (uncomment if needed)
        Get.snackbar("SignIn", "Admin Signed In Successfully",
            colorText: Colors.white);
        return Get.offAll(AdminDashboard()); // Exit function after navigating
      }

      // Check if user exists in "Users" collection
      var userDoc = await FirebaseFirestore.instance
          .collection("Users")
          .doc(user.uid)
          .get();
      if (userDoc.exists) {
        var userData = userDoc.data() as Map<String, dynamic>;
        bool isBlocked =
            userData['isBlocked'] ?? false; // Default to false if not set

        if (isBlocked) {
          // User is blocked
          Get.snackbar("Error", "Your account is blocked.",
              colorText: Colors.white);
          await FirebaseAuth.instance.signOut(); // Log out the user
          return Get.offAll(LoginPage()); // Exit function after navigating
        } else {
          // User is unblocked
          await setprefs(userData); // Save user preferences
          // await saveUserFcmToken(user.uid); // Save FCM token for user (uncomment if needed)
          Get.snackbar("SignIn", "User Signed In Successfully",
              colorText: Colors.white);
          return Get.offAll(UserDashboard()); // Exit function after navigating
        }
      } else {
        // User does not exist in either collection
        Get.snackbar("Error", "User does not exist in any collection.",
            colorText: Colors.white);
        await FirebaseAuth.instance.signOut(); // Log out the user
      }
    } catch (e) {
      print("Error checking user: $e");
      Get.snackbar("Error", "An error occurred while checking user.",
          colorText: Colors.white);
    }
  }

  Future<void> signin(BuildContext context) async {
    // Show a loading dialog while the sign-in process is ongoing
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return Center(
          child: LoadingAnimationWidget.staggeredDotsWave(
            color: Color(0xFFFF7643),
            size: 50,
          ),
        );
      },
    );

    try {
      final FirebaseAuth auth = FirebaseAuth.instance;
      UserCredential userCredential = await auth.signInWithEmailAndPassword(
        email: Email.text,
        password: Password.text,
      );
      final user = userCredential.user;

      if (user == null) {
        throw Exception("User not found.");
      }

      // Update user status to logged in
      await _updateUserStatus(user.uid, true);

      // Save FCM token for the user
      await saveUserFcmToken(user.uid);

      // Check user type and status
      await checkUser(user);
    } catch (e) {
      print(e);

      // Error handling based on the type of Firebase Auth error
      if (e.toString().contains('[firebase_auth/channel-error]')) {
        Get.snackbar("Error", "Fill All Fields",
            colorText: Colors.white, duration: Duration(seconds: 5));
      } else if (e.toString().contains('[firebase_auth/invalid-credential]')) {
        Get.snackbar("Error", "Invalid Email or Password",
            colorText: Colors.white, duration: Duration(seconds: 5));
      } else if (e.toString().contains('[firebase_auth/invalid-email]')) {
        Get.snackbar("Error", "Invalid Email",
            colorText: Colors.white, duration: Duration(seconds: 5));
      } else {
        Get.snackbar("Error", e.toString(),
            colorText: Colors.white, duration: Duration(seconds: 5));
      }
    } finally {
      // Close the loading dialog if it is open
      if (Navigator.canPop(context)) {
        Navigator.pop(context);
      }
    }
  }
}
