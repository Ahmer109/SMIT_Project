// ignore_for_file: prefer_const_constructors, non_constant_identifier_names, avoid_print, use_build_context_synchronously

import 'dart:io';

import 'package:bcrypt/bcrypt.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:smit_project/Admin%20Screens/AdminDashboard.dart';
import 'package:smit_project/Auth/LoginPage.dart';
import 'package:smit_project/Auth/Wrapper.dart';
import 'package:smit_project/User%20Screens/UserDashboard.dart';

class Registercontroller {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController userController = TextEditingController();

  
  Future<void> saveUserFcmToken(String userId) async {
    String? fcmToken = await FirebaseMessaging.instance.getToken();
    if (fcmToken != null) {
      await FirebaseFirestore.instance.collection('Users').doc(userId).set(
          {
            'fcmToken': fcmToken,
            // Other user details
          },
          SetOptions(
              merge: true)); // Use merge to avoid overwriting existing data
    }
  }

  Future<void> signup(BuildContext context) async {
    showDialog(
      context: context,
      barrierDismissible:
          false, // Prevent closing the dialog by tapping outside
      builder: (context) {
        return Center(
          child: CircularProgressIndicator(color: Colors.green),
        );
      },
    );

    try {
      // Ensure the password is not empty
      if (passwordController.text.isEmpty) {
        throw Exception("Password cannot be empty");
      }

      // Generate a salt
      String salt = BCrypt.gensalt();
      // Hash the password with the generated salt
      String hashedPassword = BCrypt.hashpw(passwordController.text, salt);

      UserCredential userCredential =
          await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: emailController.text,
        password: passwordController.text, // Firebase requires this too
      );

      // Save user data in Firestore with hashed password
      await FirebaseFirestore.instance
          .collection("Users")
          .doc(userCredential.user!.uid)
          .set({
        "name": userController.text,
        "Email": emailController.text,
        "Password": hashedPassword, // Store hashed password
        "Type": "Users"
      });
      await saveUserFcmToken(
          userCredential.user!.uid); // Save FCM token for push notifications
      _updateUserStatus(userCredential.user!.uid, true);

      Get.snackbar("SignIn", "User Registered and SignIn Successfully",
          colorText: Colors.white);
      Get.offAll(Wrapper());
    } catch (e) {
      print("Error: $e");
      Get.snackbar("Error", e.toString(),
          colorText: Colors.white, duration: Duration(seconds: 5));
    } finally {
      Navigator.of(context).pop(); // Close the loading dialog
    }
  }

  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  User? _user;

  Future<void> _updateUserStatus(String userId, bool isLoggedIn) async {
    await firestore.collection('Users').doc(userId).update({
      'isLoggedIn': isLoggedIn,
    });
  }

  Future<void> checkUser(User user) async {
    try {
      // Check if user exists in "admin" collection
      var adminDoc = await FirebaseFirestore.instance
          .collection("admin")
          .doc(user.uid)
          .get();
      if (adminDoc.exists) {
        var adminData = adminDoc.data() as Map<String, dynamic>;

        // Check if admin user is blocked
        if (adminData['isBlocked'] == true) {
          Get.snackbar("Error", "Your account is blocked.",
              colorText: Colors.white);
          await FirebaseAuth.instance.signOut(); // Log out the user
          return Get.offAll(LoginPage()); // Exit function after navigating
        }

        await setprefs(adminData); // Save preferences
        Get.snackbar("SignIn", "Admin Signed In Successfully",
            colorText: Colors.white);
        return Get.offAll(AdminDashboard()); // Exit function after navigating
      }

      // Check if user exists in "Users" collection
      var userDoc = await FirebaseFirestore.instance
          .collection("Users")
          .doc(user.uid)
          .get();
      if (userDoc.exists) {
        var userData = userDoc.data() as Map<String, dynamic>;
        bool isBlocked =
            userData['isBlocked'] ?? false; // Default to false if not set

        if (isBlocked) {
          Get.snackbar("Error", "Your account is blocked.",
              colorText: Colors.white);
          await FirebaseAuth.instance.signOut(); // Log out the user
          return Get.offAll(LoginPage()); // Exit function after navigating
        } else {
          await setprefs(userData); // Save preferences
          Get.snackbar("SignIn", "User Signed In Successfully",
              colorText: Colors.white);
          return Get.offAll(UserDashboard()); // Exit function after navigating
        }
      } else {
        Get.snackbar("Error", "User does not exist in any collection.",
            colorText: Colors.white);
        await FirebaseAuth.instance.signOut(); // Log out the user
      }
    } catch (e) {
      print("Error checking user: $e");
      Get.snackbar("Error", "An error occurred while checking user.",
          colorText: Colors.white);
    }
  }
}
Future<void> setprefs(Map<String, dynamic> data) async {
  // Placeholder for setting preferences
  // Implement your actual preferences setting logic here
}
