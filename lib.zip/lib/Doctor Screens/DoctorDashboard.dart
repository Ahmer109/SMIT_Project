import 'package:flutter/material.dart';

class DoctorDashboard extends StatefulWidget {
  const DoctorDashboard({super.key});

  @override
  State<DoctorDashboard> createState() => _DoctorDashboardState();
}

class _DoctorDashboardState extends State<DoctorDashboard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Widget'),
      ),
      body: Center(
        child: Text('Hello, World!'),
      ),
      // floatingActionButton: FloatingActionButton(
      //   onPressed: () {
      //     showDialog(
      //       context: context,
      //       child: AlertDialog(
      //         title: Text('Dialog Title'),
      //         content: Text('Dialog Content'),
      //         actions: [
      //     //       FlatButton(
      //     //         onPressed: () {
      //     //           Navigator.pop(context);
      //     //         },
      //     //         child: Text('Close'),
      //     //       )
      //         ],
      //       ),
      //     );
      //   },
      //   child: Icon(Icons.add),
      // ),
      drawer: Drawer(
        child: ListView(
          children: [
            ListTile(
              title: Text('Item 1'),
            ),
            ListTile(
              title: Text('Item 2'),
            ),
            ListTile(
              title: Text('Item 3'),
            ),
          ],
        ),
      ),
    );
  }
}