// ignore_for_file: prefer_const_constructors

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:smit_project/Auth/LoginPage.dart';
import 'package:smit_project/main.dart';

class A_DrawerController {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  User? _user;
  String name = "No user";
  String email = "No email signed in";
  String image = "https://via.placeholder.com/150"; // Placeholder for no image

  void init(VoidCallback updateUI) {
    _user = _auth.currentUser;
    if (_user != null) {
      fetchUserData(updateUI);
    }
  }

  Future<void> fetchUserData(VoidCallback updateUI) async {
    try {
      final userDoc =
          await _firestore.collection("Admin").doc(_user!.uid).get();
      if (userDoc.exists) {
        name = userDoc.data()?['name'] ?? "No user";
        email = userDoc.data()?['Email'] ?? "No email signed in";
        image = userDoc.data()?['image'] ?? "https://via.placeholder.com/150";
        updateUI(); // Update the UI
      }
    } catch (e) {
      Get.snackbar("Error", "Failed to fetch user data: ${e.toString()}");
    }
  }

  Future<void> signOut() async {
    try {
      if (_user != null) {
        // await _updateUserStatus(_user!.uid, false);
      }
      await _googleSignIn.signOut();
      await _auth.signOut();
      Get.snackbar("SignOut", "User signed out successfully.");
      Get.offAll(LoginPage());
    } catch (e) {
      Get.snackbar("Error", "Error signing out: ${e.toString()}");
    }
  }

  Widget buildHeader() {
    return Column(
      children: [
        CircleAvatar(
          radius: 50,
          backgroundImage: NetworkImage(image),
        ),
        SizedBox(height: 10),
        Text(
          "Name: $name",
          style: TextStyle(fontSize: 16),
        ),
        SizedBox(height: 5),
        Text(
          "Email: $email",
          style: TextStyle(fontSize: 16),
        ),
      ],
    );
  }

  Widget buildDrawerItem(String title, IconData icon, Function onTap) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
      child: Card(
        elevation: 10,
        child: ListTile(
          title: Text(title),
          leading: Icon(icon, color: Colors.red),
          onTap: () => onTap(),
        ),
      ),
    );
  }

  Widget buildThemeSwitch(ThemeProvider themeProvider) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: GestureDetector(
        onTap: () => themeProvider.toggleTheme(),
        child: AnimatedSwitcher(
          duration: Duration(milliseconds: 300),
          transitionBuilder: (Widget child, Animation<double> animation) {
            return ScaleTransition(child: child, scale: animation);
          },
          child: themeProvider.isDarkMode
              ? Icon(
                  Icons.wb_sunny, // Sun icon
                  key: ValueKey('light'),
                  color: Colors.orange,
                  size: 30,
                )
              : Icon(
                  Icons.nights_stay, // Moon icon
                  key: ValueKey('dark'),
                  color: Colors.black,
                  size: 30,
                ),
        ),
      ),
    );
  }
}
