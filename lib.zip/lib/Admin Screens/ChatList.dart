// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:smit_project/Admin%20Screens/AdminDrawer.dart';
// import 'package:smit_project/Admin%20Screens/ChatScreen.dart';

// class UserListScreen extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Chat List'),
//       ),
//       drawer: Drawer(
//         child: Drawerdata(),
//       ),
//       body: StreamBuilder<QuerySnapshot>(
//         stream: FirebaseFirestore.instance.collection('Users').snapshots(),
//         builder: (context, snapshot) {
//           if (!snapshot.hasData) {
//             return Center(child: CircularProgressIndicator());
//           }

//           final users = snapshot.data!.docs;

//           return ListView.builder(
//             shrinkWrap: true,
//             itemCount: users.length,
//             itemBuilder: (context, index) {
//               final user = users[index];
//               final userId = user.id; // User ID from document ID
//               final userData = user.data() as Map<String, dynamic>; // Get user data as a map

//               // Check if fields exist and assign default values if they don't
//               final userName = userData.containsKey('name') ? userData['name'] : 'No name';
//               final userEmail = userData.containsKey('Email') ? userData['Email'] : 'No email';

//               return Column(
//                 children: [
//                   ListTile(
//                     leading: CircleAvatar(
//                       backgroundImage: userData['image'] != null
//                           ? NetworkImage(userData['image'])
//                           : null,
//                       radius: 25,
//                     ),
//                     title: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Text(userName),
//                         Text(userEmail),
//                       ],
//                     ),
//                     onTap: () {
//                       Navigator.push(
//                         context,
//                         MaterialPageRoute(
//                           builder: (context) => AdminConversationScreen(
//                             userId: userId,
//                             userName: userName,
//                           ),
//                         ),
//                       );
//                     },
//                   ),
//                   Divider(thickness: 1),
//                 ],
//               );
//             },
//           );
//         },
//       ),
//     );
//   }
// }


import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:smit_project/Admin%20Screens/AdminDrawer.dart';
import 'package:smit_project/Admin%20Screens/ChatScreen.dart';

class UserListScreen extends StatefulWidget {
  @override
  State<UserListScreen> createState() => _UserListScreenState();
}

class _UserListScreenState extends State<UserListScreen> {
  String searchQuery = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chat List'),
      ),
      drawer: Drawer(
        child: Drawerdata(),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search users...',
                filled: true,
                fillColor: Colors.black12,
                border: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey),
                  borderRadius: BorderRadius.circular(20),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey),
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              onChanged: (value) {
                setState(() {
                  searchQuery = value.toLowerCase();
                });
              },
            ),
          ),
          Expanded(
            child: Container(
              color: Colors.black12,
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance.collection('Users').snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return Center(child: CircularProgressIndicator());
                  }

                  final allUsers = snapshot.data!.docs;
                  final filteredUsers = allUsers.where((doc) {
                    final userData = doc.data() as Map<String, dynamic>;
                    final name = userData['name']?.toString().toLowerCase() ?? '';
                    final email = userData['Email']?.toString().toLowerCase() ?? '';
                    return name.contains(searchQuery) || email.contains(searchQuery);
                  }).toList();

                  if (filteredUsers.isEmpty) {
                    return Center(child: Text('No users found.'));
                  }

                  return ListView.builder(
                    itemCount: filteredUsers.length,
                    itemBuilder: (context, index) {
                      final user = filteredUsers[index];
                      final userId = user.id; // User ID from document ID
                      final userData = user.data() as Map<String, dynamic>; // Get user data as a map

                      // Check if fields exist and assign default values if they don't
                      final userName = userData.containsKey('name') ? userData['name'] : 'No name';
                      final userEmail = userData.containsKey('Email') ? userData['Email'] : 'No email';

                      return Column(
                        children: [
                          ListTile(
                            leading: CircleAvatar(
                              backgroundImage: userData['image'] != null
                                  ? NetworkImage(userData['image'])
                                  : null,
                              radius: 25,
                            ),
                            title: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(userName),
                                Text(userEmail),
                              ],
                            ),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => AdminConversationScreen(
                                    userId: userId,
                                    userName: userName,
                                  ),
                                ),
                              );
                            },
                          ),
                          Divider(thickness: 1),
                        ],
                      );
                    },
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
