// ignore_for_file: file_names, prefer_const_constructors, use_build_context_synchronously, avoid_print

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:smit_project/Admin%20Screens/AdminDrawer.dart';

class Userslist extends StatefulWidget {
  const Userslist({super.key});

  @override
  State<Userslist> createState() => _UserslistState();
}

class _UserslistState extends State<Userslist> {
  final CollectionReference usersCollection = FirebaseFirestore.instance.collection('Users');
  String searchQuery = "";

  Future<void> toggleBlockUser(String userId, bool isBlocked) async {
    try {
      await usersCollection.doc(userId).update({
        'isBlocked': !isBlocked,
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(isBlocked ? 'User Unblocked' : 'User Blocked', style: TextStyle(color: Colors.white)),
          backgroundColor: const Color.fromARGB(255, 133, 18, 9),
        ),
      );
    } catch (e) {
      print("Error updating user status: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to update user status.'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Users List'),
      ),
      drawer: Drawer(
        child: Drawerdata(),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search users...',
                filled: true,
                fillColor: Colors.black12,
                border: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey),
                  borderRadius: BorderRadius.circular(20),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey),
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              onChanged: (value) {
                setState(() {
                  searchQuery = value.toLowerCase();
                });
              },
            ),
          ),
          Expanded(
            child: Container(
              color: Colors.black12,
              child: StreamBuilder<QuerySnapshot>(
                stream: usersCollection.snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }
                  if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}'));
                  }
                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return Center(child: Text('No users found.'));
                  }
                  final allUsers = snapshot.data!.docs;
                  final filteredUsers = allUsers.where((doc) {
                    final userData = doc.data() as Map<String, dynamic>;
                    final name = userData['name']?.toString().toLowerCase() ?? '';
                    final email = userData['Email']?.toString().toLowerCase() ?? '';
                    return name.contains(searchQuery) || email.contains(searchQuery);
                  }).toList();

                  return ListView.builder(
                    itemCount: filteredUsers.length,
                    itemBuilder: (context, index) {
                      final userData = filteredUsers[index].data() as Map<String, dynamic>;
                      final userId = filteredUsers[index].id;
                      final isBlocked = userData['isBlocked'] ?? false; // Default to false if not set

                      return Column(
                        children: [
                          ListTile(
                            leading: CircleAvatar(
                              backgroundImage: userData['image'] != null
                                  ? NetworkImage(userData['image'])
                                  : null,
                              radius: 25,
                            ),
                            title: Text(userData['name'] ?? 'No name'),
                            subtitle: Text(userData['Email'] ?? 'No email'),
                            trailing: TextButton(
                              child: Text(isBlocked ? 'Unblock' : 'Block'),
                              onPressed: () => toggleBlockUser(userId, isBlocked),
                            ),
                          ),
                          Divider(), // Add a divider between each user list item
                        ],
                      );
                    },
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
