// // ignore_for_file: prefer_const_constructors

// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:smit_project/Admin%20Screens/AdminDrawer.dart';


// class UserLoggedinScreen extends StatefulWidget {
//   @override
//   State<UserLoggedinScreen> createState() => _UserLoggedinScreenState();
// }

// class _UserLoggedinScreenState extends State<UserLoggedinScreen> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Logged-In Users'),
//       ),
//       drawer: Drawer(
//         child: Drawerdata(),
//       ),
//       body: StreamBuilder<QuerySnapshot>(
//         stream: FirebaseFirestore.instance
//             .collection('Users')
//             .where('isLoggedIn', isEqualTo: true) // Filter for logged-in users
//             .snapshots(),
//         builder: (context, snapshot) {
//           if (!snapshot.hasData) {
//             return Center(child: CircularProgressIndicator());
//           }

//           final users = snapshot.data!.docs;

//           if (users.isEmpty) {
//             return Center(child: Text('No logged-in users found.'));
//           }

//           return ListView.builder(
//             itemCount: users.length,
//             itemBuilder: (context, index) {
//               final user = users[index];
//               final userData = user.data() as Map<String, dynamic>; // Get user data as a map
//               return Card(
//                 margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
//                 child: ListTile(
//                   leading: CircleAvatar(
//                     backgroundImage: NetworkImage(userData['image'] ?? ''),
//                     radius: 25,
//                   ),
//                   title: Text(userData['name'] ?? 'No name'),
//                   subtitle: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text('Email: ${userData['Email'] ?? 'No email'}'),
//                       Text('Last Sign In: ${userData['lastSignIn']?.toDate().toString() ?? 'No date'}'),
//                       Text("Login Status: ${userData['isLoggedIn']?? 'No Login Status'}"),
//                     ],
//                   ),
//                 ),
//               );
//             },
//           );
//         },
//       ),
//     );
//   }
// }

// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:smit_project/Admin%20Screens/AdminDrawer.dart';

class UserLoggedinScreen extends StatefulWidget {
  @override
  State<UserLoggedinScreen> createState() => _UserLoggedinScreenState();
}

class _UserLoggedinScreenState extends State<UserLoggedinScreen> {
  String searchQuery = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Logged-In Users'),
      ),
      drawer: Drawer(
        child: Drawerdata(),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search logged-in users...',
                filled: true,
                fillColor: Colors.black12,
                border: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey),
                  borderRadius: BorderRadius.circular(20),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey),
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              onChanged: (value) {
                setState(() {
                  searchQuery = value.toLowerCase();
                });
              },
            ),
          ),
          Expanded(
            child: Container(
              color: Colors.black12,
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('Users')
                    .where('isLoggedIn', isEqualTo: true) // Filter for logged-in users
                    .snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return Center(child: CircularProgressIndicator());
                  }

                  final users = snapshot.data!.docs;
                  final filteredUsers = users.where((doc) {
                    final userData = doc.data() as Map<String, dynamic>;
                    final name = userData['name']?.toString().toLowerCase() ?? '';
                    final email = userData['Email']?.toString().toLowerCase() ?? '';
                    return name.contains(searchQuery) || email.contains(searchQuery);
                  }).toList();

                  if (filteredUsers.isEmpty) {
                    return Center(child: Text('No logged-in users found.'));
                  }

                  return ListView.builder(
                    itemCount: filteredUsers.length,
                    itemBuilder: (context, index) {
                      final user = filteredUsers[index];
                      final userData = user.data() as Map<String, dynamic>; // Get user data as a map
                      return Card(
                        margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundImage: NetworkImage(userData['image'] ?? ''),
                            radius: 25,
                          ),
                          title: Text(userData['name'] ?? 'No name'),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Email: ${userData['Email'] ?? 'No email'}'),
                              Text('Last Sign In: ${userData['lastSignIn']?.toDate().toString() ?? 'No date'}'),
                              Text("Login Status: ${userData['isLoggedIn']?? 'No Login Status'}"),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
