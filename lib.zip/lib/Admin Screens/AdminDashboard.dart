// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:smit_project/Admin%20Screens/AdminDrawer.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Admin Dashboard'),
      ),
      drawer: Drawer(
        child: Drawerdata(),
      ),
    );
  }
}