// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:smit_project/Admin%20Screens/AdminDrawer.dart';

// class Adddoctor extends StatefulWidget {
//   @override
//   _AdddoctorState createState() => _AdddoctorState();
// }

// class _AdddoctorState extends State<Adddoctor> {
//   final TextEditingController _nameController = TextEditingController();
//   final TextEditingController _emailController = TextEditingController();
//   final TextEditingController _passwordController = TextEditingController();
//   String? _selectedCategory;

//   final List<String> _categories = ['Cardiologist', 'Dermatologist', 'Neurologist', 'Pediatrician'];

//   final FirebaseFirestore _firestore = FirebaseFirestore.instance;
//   final FirebaseAuth _auth = FirebaseAuth.instance;

//   void _saveDoctor() async {
//     final String name = _nameController.text.trim();
//     final String email = _emailController.text.trim();
//     final String password = _passwordController.text.trim();
//     final String? category = _selectedCategory;

//     if (name.isEmpty || email.isEmpty || password.isEmpty || category == null) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Please fill all fields and select a category.')),
//       );
//       return;
//     }

//     try {
//       // Create user in Firebase Authentication
//       UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
//         email: email,
//         password: password,
//       );

//       // Save doctor details to Firestore under "Doctors/{Category}/{DoctorId}"
//       await _firestore
//           .collection('Doctors') // Main collection
//           .doc(category) // Category as a document
//           .collection('Doctors') // Sub-collection under category
//           .doc(userCredential.user!.uid) // Doctor document ID as user UID
//           .set({
//         'name': name,
//         'email': email,
//         'category': category,
//         'Password' : password,
//         'Type' : "Doctor"
//       });

//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Doctor added successfully!')),
//       );

//       // Clear form fields
//       _nameController.clear();
//       _emailController.clear();
//       _passwordController.clear();
//       setState(() {
//         _selectedCategory = null;
//       });
//     } on FirebaseAuthException catch (e) {
//       String errorMessage;
//       if (e.code == 'email-already-in-use') {
//         errorMessage = 'This email is already registered.';
//       } else if (e.code == 'weak-password') {
//         errorMessage = 'The password is too weak.';
//       } else {
//         errorMessage = 'An error occurred: ${e.message}';
//       }
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text(errorMessage)),
//       );
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Error: ${e.toString()}')),
//       );
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Add Doctor'),
//       ),
//       drawer: Drawer(
//         child: Drawerdata(),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             TextField(
//               controller: _nameController,
//               decoration: InputDecoration(labelText: 'Doctor Name'),
//             ),
//             TextField(
//               controller: _emailController,
//               decoration: InputDecoration(labelText: 'Doctor Email'),
//             ),
//             TextField(
//               controller: _passwordController,
//               decoration: InputDecoration(labelText: 'Doctor Password'),
//               obscureText: true,
//             ),
//             SizedBox(height: 16),
//             DropdownButtonFormField<String>(
//               value: _selectedCategory,
//               decoration: InputDecoration(labelText: 'Select Category'),
//               items: _categories.map((category) {
//                 return DropdownMenuItem(value: category, child: Text(category));
//               }).toList(),
//               onChanged: (value) {
//                 setState(() {
//                   _selectedCategory = value;
//                 });
//               },
//             ),
//             SizedBox(height: 20),
//             ElevatedButton(
//               onPressed: _saveDoctor,
//               child: Text('Save Doctor'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
