// ignore_for_file: use_super_parameters, prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:get/get.dart';
import 'package:smit_project/Admin%20Screens/AddDoctor.dart';
import 'package:smit_project/Admin%20Screens/AdminControllers/DrawerController.dart';
import 'package:smit_project/main.dart';
import 'package:smit_project/Admin%20Screens/AdminDashboard.dart';
import 'package:smit_project/Admin%20Screens/ChatList.dart';
import 'package:smit_project/Admin%20Screens/CurrentLoggendin.dart';
import 'package:smit_project/Admin%20Screens/UserList.dart';

class Drawerdata extends StatefulWidget {
  const Drawerdata({Key? key}) : super(key: key);

  @override
  State<Drawerdata> createState() => _DrawerdataState();
}

class _DrawerdataState extends State<Drawerdata> {
  final A_DrawerController _controller = A_DrawerController();

  @override
  void initState() {
    super.initState();
    _controller.init(() {
      setState(() {}); // Update the UI when data is fetched
    });
  }

  Future<void> _signOut() async {
    await _controller.signOut();
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    return Drawer(
      child: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  _controller.buildThemeSwitch(themeProvider),
                ],
              ),
            ),
            _controller.buildHeader(),
            Divider(color: Colors.grey),
            _controller.buildDrawerItem("Home", Icons.home, () {
              Get.off(AdminDashboard());
            }),
            // _controller.buildDrawerItem("Add Doctor", Icons.add_box_rounded, () {
            //   Get.off(Adddoctor());
            // }),
            _controller.buildDrawerItem("Chats", Icons.chat, () {
              Get.off(UserListScreen());
            }),
            _controller.buildDrawerItem("Users", Icons.people, () {
              Get.off(Userslist());
            }),
            _controller.buildDrawerItem("Logged-In Users", Icons.people, () {
              // if (_user != null) {
              Get.off(UserLoggedinScreen());
              // } else {
              //   Get.snackbar("Error", "No user is currently logged in.");
              // }
            }),
            _controller.buildDrawerItem("Log Out", Icons.logout, () {
              _signOut();
            }),
          ],
        ),
      ),
    );
  }
}
