// ignore_for_file: file_names, prefer_const_constructors, curly_braces_in_flow_control_structures, library_private_types_in_public_api, use_key_in_widget_constructors

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AdminConversationScreen extends StatefulWidget {
  final String userId;
  final String userName;

  AdminConversationScreen({required this.userId, required this.userName});

  @override
  _AdminConversationScreenState createState() => _AdminConversationScreenState();
}

class _AdminConversationScreenState extends State<AdminConversationScreen> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _sendMessage() async {
    if (_messageController.text.isNotEmpty) {
      final messageText = _messageController.text;
      // Save message to Firestore
      await FirebaseFirestore.instance.collection('messages_${widget.userId}').add({
        'text': messageText,
        'sender': 'admin',
        'timestamp': FieldValue.serverTimestamp(),
      });
      _messageController.clear();

      // Send notification to user
      _sendNotification(messageText);
    }
  }

  Future<void> _sendNotification(String message) async {
    try {
      // Fetch the user's FCM token from Firestore
      final userDoc = await FirebaseFirestore.instance
          .collection('Users')
          .doc(widget.userId)
          .get();
      final userToken = userDoc.data()?['fcmToken'];

      if (userToken != null) {
        // Prepare notification data
        final notificationData = {
          "to": userToken,
          "notification": {
            "title": "Message from Admin",
            "body": message,
            "sound": "default",
          },
          "data": {
            "click_action": "FLUTTER_NOTIFICATION_CLICK",
            "message": message,
          },
        };

        // Send the notification using FCM HTTP endpoint
        final response = await http.post(
          Uri.parse("https://fcm.googleapis.com/fcm/send"),
          headers: {
            "Content-Type": "application/json",
            "Authorization": "key=YOUR_SERVER_KEY", // Replace with your FCM server key
          },
          body: jsonEncode(notificationData),
        );

        if (response.statusCode == 200) {
          print("Notification sent successfully");
        } else {
          print("Failed to send notification: ${response.statusCode}");
        }
      } else {
        print("User token not found");
      }
    } catch (e) {
      print("Error sending notification: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chat with ${widget.userName}'),
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('messages_${widget.userId}')
                  .orderBy('timestamp')
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return Center(child: CircularProgressIndicator());
                }

                final messages = snapshot.data!.docs;
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
                });

                return ListView.builder(
                  controller: _scrollController,
                  itemCount: messages.length,
                  itemBuilder: (context, index) {
                    final message = messages[index]['text'];
                    final sender = messages[index]['sender'];

                    return Align(
                      alignment: sender == 'admin'
                          ? Alignment.centerRight
                          : Alignment.centerLeft,
                      child: Container(
                        margin: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: sender == 'admin' ? Colors.blue : Colors.grey[300],
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          message,
                          style: TextStyle(
                            color: sender == 'admin' ? Colors.white : Colors.black,
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: InputDecoration(
                      hintText: 'Enter your message...',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send, color: Colors.red),
                  onPressed: _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
