// ignore_for_file: prefer_const_constructors, file_names

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:smit_project/User%20Screens/UserController/DrawerController.dart';
import 'package:smit_project/User%20Screens/UserConversation.dart';
import 'package:smit_project/User%20Screens/UserDashboard.dart';
import 'package:smit_project/main.dart';

class UDrawerdata extends StatefulWidget {
  const UDrawerdata({Key? key}) : super(key: key);

  @override
  State<UDrawerdata> createState() => _UDrawerdataState();
}

class _UDrawerdataState extends State<UDrawerdata> {
  final Drawercontroller _controller = Drawercontroller();

  @override
  void initState() {
    super.initState();
    _controller.fetchUserData(() {
      setState(() {}); // Callback to update the UI
    });
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);

    return Drawer(
      child: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  _buildThemeSwitch(themeProvider),
                ],
              ),
            ),
            CircleAvatar(
              radius: 50,
              backgroundImage: NetworkImage(_controller.image),
              backgroundColor: Colors.transparent,
            ),
            SizedBox(height: 10),
            Text("Name: ${_controller.name}"),
            Text("Email: ${_controller.email}"),
            Divider(color: Colors.grey),
            buildDrawerItem("Home", Icons.home, () {
              Get.off(UserDashboard());
            }),
            buildDrawerItem("Chat With Admin", Icons.chat, () {
              if (_controller.currentUser != null) {
                Get.to(UserConversationScreen(
                  userName: _controller.name,
                  userId: _controller.currentUser!.uid,
                ));
              } else {
                Get.snackbar("Error", "User not logged in.");
              }
            }),
            buildDrawerItem("Log Out", Icons.logout, () {
              _controller.signOut(context);
            }),
          ],
        ),
      ),
    );
  }

  Widget buildDrawerItem(String title, IconData icon, Function() onTap) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
      child: Card(
        elevation: 10,
        child: ListTile(
          title: Text(title),
          leading: Icon(icon, color: Colors.red),
          onTap: onTap,
        ),
      ),
    );
  }

  Widget _buildThemeSwitch(ThemeProvider themeProvider) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: GestureDetector(
        onTap: () => themeProvider.toggleTheme(),
        child: AnimatedSwitcher(
            duration: Duration(milliseconds: 300),
            transitionBuilder: (Widget child, Animation<double> animation) {
              return ScaleTransition(child: child, scale: animation);
            },
            child: themeProvider.isDarkMode
                ? Icon(
                    Icons.wb_sunny, // Sun icon
                    key: ValueKey('light'),
                    color: Colors.orange,
                    size: 30,
                  )
                : Icon(
                    Icons.nights_stay, // Moon icon
                    key: ValueKey('dark'),
                    color: Colors.black,
                    size: 30,
                  )),
      ),
    );
  }
}
