// ignore_for_file: file_names

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:get/get.dart';
import 'package:smit_project/Auth/LoginPage.dart';

class Drawercontroller {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  final currentUser = FirebaseAuth.instance.currentUser;
  var name = "No user";
  var email = "No email signed in";
  var image = "https://via.placeholder.com/150"; // Default image URL

  Future<void> fetchUserData(VoidCallback updateUI) async {
    if (currentUser != null) {
      try {
        final userDoc = await FirebaseFirestore.instance
            .collection("Users")
            .doc(currentUser!.uid)
            .get();
        if (userDoc.exists) {
          name = userDoc['name'] ?? "No user";
          email = userDoc['Email'] ?? "No email signed in";
          image = userDoc['image'] ?? image; // Use default image if none found
          updateUI();
        }
      } catch (e) {
        print("Error fetching user data: ${e.toString()}");
      }
    }
  }

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  User? _user;

  Future<void> signOut(BuildContext context) async {
    _user = _auth.currentUser;
    if (_user != null) {
      try {
        await _updateUserStatus(_user!.uid, false);
        await _googleSignIn.signOut();
        await _auth.signOut();
        Get.snackbar("SignOut", "User signed out successfully.");
        Get.offAll(LoginPage());
      } catch (e) {
        Get.snackbar("Error", "Error signing out: ${e.toString()}");
      }
    } else {
      Get.snackbar("Info", "No user is currently signed in.",
          colorText: Colors.white);
    }
  }

  Future<void> _updateUserStatus(String userId, bool isLoggedIn) async {
    try {
      await _firestore.collection('Users').doc(userId).update({
        'isLoggedIn': isLoggedIn,
      });
      print("User status updated to: $isLoggedIn");
    } catch (e) {
      print("Error updating user status: $e");
    }
  }
}
